'use client';

import { useState, useMemo, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle2, XCircle } from 'lucide-react';

interface FormData {
  // Identitas
  namaLengkap: string;
  noIdentitas: string;
  alamat: string;
  noTelepon: string;

  // Pekerjaan
  jenisPekerjaan: 'pns' | 'swasta_tetap' | 'kontrak' | 'wiraswasta' | '';
  namaPerusahaan: string;
  jabatan: string;
  masaKerjaTahun: number;

  // Pendapatan & Modal
  pendapatanBersih: number;
  cicilanBerjalan: number;
  asetLikuid: number;
  totalHutang: number;
  totalModal: number;

  // Properti
  hargaProperti: number;
  dp: number;
  tenor: number;
  sukuBunga: number;

  // Character (6 params) - Max 30 poin (5 poin per param)
  hubunganBank: 0 | 2 | 3 | 5 | '';
  riwayatKredit: 0 | 3 | 5 | '';
  kedisiplinan: 0 | 3 | 5 | '';
  reputasi: 0 | 3 | 5 | '';
  stabilitasTinggal: 0 | 3 | 5 | '';
  catatanHukum: 0 | 3 | 5 | '';

  // Capacity (4 params) - Max 25 poin
  dsr: 0 | 4 | 6 | '';
  stabilitasPendapatan: 0 | 3 | 6 | '';
  pertumbuhanKeuntungan: 0 | 3 | 6 | '';
  bopo: 0 | 3 | 6 | '';

  // Capital (3 params) - Max 20 poin
  selfFinancing: 0 | 3 | 6 | '';
  der: 0 | 3 | 6 | '';
  asetLikuidScore: 0 | 3 | 6 | '';

  // Collateral (3 params) - Max 15 poin
  ltv: 0 | 6 | 10 | '';
  likuiditasJaminan: 0 | 3 | 5 | '';
  legalitasJaminan: 0 | 3 | 5 | '';

  // Condition (2 params) - Max 10 poin
  jenisPekerjaanScore: 0 | 3 | 5 | '';
  prospekSektor: 0 | 3 | 5 | '';
}

interface ScoringResult {
  character: number;
  capacity: number;
  capital: number;
  collateral: number;
  condition: number;
  total: number;
  decision: 'approved' | 'considered' | 'risky' | 'rejected';
  metrics: {
    dbr: number;
    dsr: number;
    ltv: number;
    der: number;
    cicilan: number;
    plafon: number;
  };
}

export default function Home() {
  const [stage, setStage] = useState<'landing' | 'form' | 'scoring' | 'results'>('landing');
  const [formData, setFormData] = useState<FormData>({
    namaLengkap: '',
    noIdentitas: '',
    alamat: '',
    noTelepon: '',
    jenisPekerjaan: '',
    namaPerusahaan: '',
    jabatan: '',
    masaKerjaTahun: 0,
    pendapatanBersih: 0,
    cicilanBerjalan: 0,
    asetLikuid: 0,
    totalHutang: 0,
    totalModal: 0,
    hargaProperti: 0,
    dp: 0,
    tenor: 10,
    sukuBunga: 0,
    hubunganBank: '',
    riwayatKredit: '',
    kedisiplinan: '',
    reputasi: '',
    stabilitasTinggal: '',
    catatanHukum: '',
    dsr: '',
    stabilitasPendapatan: '',
    pertumbuhanKeuntungan: '',
    bopo: '',
    selfFinancing: '',
    der: '',
    asetLikuidScore: '',
    ltv: '',
    likuiditasJaminan: '',
    legalitasJaminan: '',
    jenisPekerjaanScore: '',
    prospekSektor: '',
  });
  const [result, setResult] = useState<ScoringResult | null>(null);

  // Hitung metrik-metrik otomatis
  const metrics = useMemo(() => {
    const plafon = formData.hargaProperti - formData.dp;
    const monthlyRate = (formData.sukuBunga || 0) / 100 / 12;
    const nMonths = (formData.tenor || 10) * 12;

    let cicilan = 0;
    if (monthlyRate > 0 && nMonths > 0) {
      cicilan =
        plafon *
        (monthlyRate * Math.pow(1 + monthlyRate, nMonths)) /
        (Math.pow(1 + monthlyRate, nMonths) - 1);
    } else {
      cicilan = formData.tenor > 0 ? plafon / (formData.tenor * 12) : 0;
    }

    const totalCicilan = cicilan + formData.cicilanBerjalan;
    const dbr = formData.pendapatanBersih > 0 ? (totalCicilan / formData.pendapatanBersih) * 100 : 0;
    const dsr = formData.pendapatanBersih > 0 ? (cicilan / formData.pendapatanBersih) * 100 : 0;
    // LTV = Jumlah Pinjaman / Nilai Aset (dalam persen)
    // LTV = Plafon / Harga Properti × 100%
    const ltv = formData.hargaProperti > 0 ? (plafon / formData.hargaProperti) * 100 : 0;
    const der = formData.totalModal > 0 ? formData.totalHutang / formData.totalModal : 0;

    return { dbr, dsr, ltv, der, cicilan, plafon };
  }, [formData]);

  // Auto-lock scoring berdasarkan hasil perhitungan
  const getAutoLockedScore = (metricName: string, metricValue: number): (0 | 6 | 10 | '') => {
    switch (metricName) {
      case 'dsr':
        if (metricValue <= 30) return 6;
        if (metricValue <= 50) return 4;
        return 0;
      case 'ltv':
        // LTV = Plafon / Harga Properti × 100%
        // < 80% = 10 poin (sangat aman - plafon kecil)
        // 80-100% = 6 poin (cukup aman - plafon cukup)
        // > 100% = 0 poin (tidak layak - plafon melebihi nilai aset)
        if (metricValue < 80) return 10;
        if (metricValue <= 100) return 6;
        return 0;
      case 'bopo':
        if (metricValue <= 50) return 6;
        if (metricValue <= 75) return 3;
        return 0;
      default:
        return '';
    }
  };

  // Auto-update DSR, BOPO, LTV scores ketika metrics berubah
  useEffect(() => {
    const dsrScore = getAutoLockedScore('dsr', metrics.dsr);
    const ltvScore = getAutoLockedScore('ltv', metrics.ltv);
    
    setFormData((prev) => ({
      ...prev,
      dsr: dsrScore,
      ltv: ltvScore,
      // BOPO hanya untuk wiraswasta - jika ada nilai operasional
      bopo: prev.jenisPekerjaan === 'wiraswasta' ? getAutoLockedScore('bopo', metrics.der * 100) : (0 as any),
    }));
  }, [metrics]);

  const handleInputChange = (field: keyof FormData, value: any) => {
    // Jangan update DSR, BOPO, LTV - auto-locked
    if (field === 'dsr' || field === 'bopo' || field === 'ltv') {
      return;
    }
    setFormData((prev) => ({
      ...prev,
      [field]: value === '' ? '' : value,
    }));
  };

  const handleProcess = () => {
    // Validasi DBR dulu
    if (metrics.dbr > 50) {
      setResult({
        character: 0,
        capacity: 0,
        capital: 0,
        collateral: 0,
        condition: 0,
        total: 0,
        decision: 'rejected',
        metrics,
      });
      setStage('results');
      return;
    }

    // Hitung skor
    const characterScore =
      (formData.hubunganBank || 0) +
      (formData.riwayatKredit || 0) +
      (formData.kedisiplinan || 0) +
      (formData.reputasi || 0) +
      (formData.stabilitasTinggal || 0) +
      (formData.catatanHukum || 0);

    const capacityScore =
      (formData.dsr || 0) +
      (formData.stabilitasPendapatan || 0) +
      (formData.pertumbuhanKeuntungan || 0) +
      (formData.bopo || 0);

    const capitalScore =
      (formData.selfFinancing || 0) +
      (formData.der || 0) +
      (formData.asetLikuidScore || 0);

    const collateralScore =
      (formData.ltv || 0) +
      (formData.likuiditasJaminan || 0) +
      (formData.legalitasJaminan || 0);

    const conditionScore =
      (formData.jenisPekerjaanScore || 0) +
      (formData.prospekSektor || 0);

    const total = characterScore + capacityScore + capitalScore + collateralScore + conditionScore;

    let decision: 'approved' | 'considered' | 'risky' | 'rejected' = 'rejected';
    if (total >= 75) decision = 'approved';
    else if (total >= 60) decision = 'considered';
    else if (total >= 45) decision = 'risky';

    setResult({
      character: characterScore,
      capacity: capacityScore,
      capital: capitalScore,
      collateral: collateralScore,
      condition: conditionScore,
      total,
      decision,
      metrics,
    });

    setStage('results');
  };

  const handleReset = () => {
    setFormData({
      namaLengkap: '',
      noIdentitas: '',
      alamat: '',
      noTelepon: '',
      jenisPekerjaan: '',
      namaPerusahaan: '',
      jabatan: '',
      masaKerjaTahun: 0,
      pendapatanBersih: 0,
      cicilanBerjalan: 0,
      asetLikuid: 0,
      totalHutang: 0,
      totalModal: 0,
      hargaProperti: 0,
      dp: 0,
      tenor: 10,
      sukuBunga: 0,
      hubunganBank: '',
      riwayatKredit: '',
      kedisiplinan: '',
      reputasi: '',
      stabilitasTinggal: '',
      catatanHukum: '',
      dsr: '',
      stabilitasPendapatan: '',
      pertumbuhanKeuntungan: '',
      bopo: '',
      selfFinancing: '',
      der: '',
      asetLikuidScore: '',
      ltv: '',
      likuiditasJaminan: '',
      legalitasJaminan: '',
      jenisPekerjaanScore: '',
      prospekSektor: '',
    });
    setResult(null);
    setStage('landing');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-blue-900 text-white border-b border-blue-950">
        <div className="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">HomeLoan Score</h1>
            <p className="text-blue-100 text-sm mt-1">Penilaian Kelayakan Kredit Properti</p>
          </div>
          {stage !== 'landing' && (
            <button
              onClick={handleReset}
              className="px-4 py-2 bg-blue-800 hover:bg-blue-700 rounded transition text-sm"
            >
              Mulai Ulang
            </button>
          )}
        </div>
      </header>

      {/* Landing */}
      {stage === 'landing' && (
        <div className="max-w-7xl mx-auto px-6 py-20 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Penilaian Kelayakan KPR</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Sistem penilaian berbasis analisis 5C untuk mengevaluasi kelayakan calon debitur
            dengan perhitungan transparan dan detail
          </p>
          <button
            onClick={() => setStage('form')}
            className="px-8 py-3 bg-blue-900 text-white rounded-lg font-semibold hover:bg-blue-800 transition"
          >
            Mulai Penilaian
          </button>
        </div>
      )}

      {/* Form Stage */}
      {stage === 'form' && (
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="grid grid-cols-3 gap-8">
            {/* Left - Form Inputs */}
            <div className="col-span-2 space-y-6">
              {/* Identitas */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Data Identitas</h3>
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Nama Lengkap"
                    value={formData.namaLengkap}
                    onChange={(e) => handleInputChange('namaLengkap', e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                  />
                  <input
                    type="text"
                    placeholder="No. Identitas"
                    value={formData.noIdentitas}
                    onChange={(e) => handleInputChange('noIdentitas', e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                  />
                  <input
                    type="text"
                    placeholder="Alamat"
                    value={formData.alamat}
                    onChange={(e) => handleInputChange('alamat', e.target.value)}
                    className="col-span-2 px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                  />
                  <input
                    type="text"
                    placeholder="No. Telepon"
                    value={formData.noTelepon}
                    onChange={(e) => handleInputChange('noTelepon', e.target.value)}
                    className="col-span-2 px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                  />
                </div>
              </Card>

              {/* Pekerjaan */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Data Pekerjaan</h3>
                <div className="grid grid-cols-2 gap-4">
                  <select
                    value={formData.jenisPekerjaan}
                    onChange={(e) => handleInputChange('jenisPekerjaan', e.target.value)}
                    className="col-span-2 px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                  >
                    <option value="">Pilih Jenis Pekerjaan</option>
                    <option value="pns">PNS</option>
                    <option value="swasta_tetap">Swasta Tetap</option>
                    <option value="kontrak">Kontrak</option>
                    <option value="wiraswasta">Wiraswasta</option>
                  </select>
                  <input
                    type="text"
                    placeholder="Nama Perusahaan"
                    value={formData.namaPerusahaan}
                    onChange={(e) => handleInputChange('namaPerusahaan', e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                  />
                  <input
                    type="text"
                    placeholder="Jabatan"
                    value={formData.jabatan}
                    onChange={(e) => handleInputChange('jabatan', e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                  />
                  <input
                    type="number"
                    placeholder="Masa Kerja (tahun)"
                    value={formData.masaKerjaTahun}
                    onChange={(e) => handleInputChange('masaKerjaTahun', parseFloat(e.target.value))}
                    className="col-span-2 px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                  />
                </div>
              </Card>

              {/* Pendapatan & Modal */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Keuangan</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-semibold text-gray-700">Pendapatan Bersih (Rp)</label>
                    <input
                      type="number"
                      value={formData.pendapatanBersih}
                      onChange={(e) => handleInputChange('pendapatanBersih', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700">Cicilan Berjalan (Rp)</label>
                    <input
                      type="number"
                      value={formData.cicilanBerjalan}
                      onChange={(e) => handleInputChange('cicilanBerjalan', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700">Aset Likuid (Rp)</label>
                    <input
                      type="number"
                      value={formData.asetLikuid}
                      onChange={(e) => handleInputChange('asetLikuid', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700">Total Hutang (Rp)</label>
                    <input
                      type="number"
                      value={formData.totalHutang}
                      onChange={(e) => handleInputChange('totalHutang', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-sm font-semibold text-gray-700">Total Modal (Rp)</label>
                    <input
                      type="number"
                      value={formData.totalModal}
                      onChange={(e) => handleInputChange('totalModal', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                </div>
              </Card>

              {/* Properti */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Simulasi KPR</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-semibold text-gray-700">Harga Properti (Rp)</label>
                    <input
                      type="number"
                      value={formData.hargaProperti}
                      onChange={(e) => handleInputChange('hargaProperti', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700">Uang Muka (Rp)</label>
                    <input
                      type="number"
                      value={formData.dp}
                      onChange={(e) => handleInputChange('dp', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700">Tenor (tahun)</label>
                    <input
                      type="number"
                      value={formData.tenor}
                      onChange={(e) => handleInputChange('tenor', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700">Suku Bunga (%/tahun)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.sukuBunga}
                      onChange={(e) => handleInputChange('sukuBunga', parseFloat(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-300 rounded bg-white text-gray-900"
                    />
                  </div>
                </div>
              </Card>

              {/* Character Scoring */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Character (Karakter Nasabah)</h3>
                <div className="space-y-4">
                  <ScoreOption
                    label="1. Hubungan dengan Bank"
                    options={[
                      { value: 5, label: 'Pernah Pinjaman Lunas' },
                      { value: 3, label: 'Sedang Punya Pinjaman Lancar' },
                      { value: 2, label: 'Sedang Punya Tabungan' },
                      { value: 0, label: 'Nasabah Baru' },
                    ]}
                    value={formData.hubunganBank}
                    onChange={(v) => handleInputChange('hubunganBank', v)}
                  />
                  <ScoreOption
                    label="2. Riwayat Kredit (SLIK/BI Checking)"
                    options={[
                      { value: 5, label: 'Kolektibilitas 1 / Lancar' },
                      { value: 3, label: 'Kolektibilitas 2 / Dalam Perhatian Khusus' },
                      { value: 0, label: 'Kolektibilitas 3-5 / Kurang Lancar-Macet' },
                    ]}
                    value={formData.riwayatKredit}
                    onChange={(v) => handleInputChange('riwayatKredit', v)}
                  />
                  <ScoreOption
                    label="3. Kedisiplinan Pembayaran"
                    options={[
                      { value: 5, label: 'Selalu Tepat Waktu' },
                      { value: 3, label: 'Kadang Terlambat' },
                      { value: 0, label: 'Sering Terlambat / Menunggak' },
                    ]}
                    value={formData.kedisiplinan}
                    onChange={(v) => handleInputChange('kedisiplinan', v)}
                  />
                  <ScoreOption
                    label="4. Reputasi dan Kepribadian"
                    options={[
                      { value: 5, label: 'Sangat Baik' },
                      { value: 3, label: 'Cukup Baik' },
                      { value: 0, label: 'Kurang Baik' },
                    ]}
                    value={formData.reputasi}
                    onChange={(v) => handleInputChange('reputasi', v)}
                  />
                  <ScoreOption
                    label="5. Stabilitas Tempat Tinggal"
                    options={[
                      { value: 5, label: 'Tinggal Tetap > 3 Tahun' },
                      { value: 3, label: 'Tinggal 1-3 Tahun' },
                      { value: 0, label: '< 1 Tahun / Sering Pindah' },
                    ]}
                    value={formData.stabilitasTinggal}
                    onChange={(v) => handleInputChange('stabilitasTinggal', v)}
                  />
                  <ScoreOption
                    label="6. Catatan Hukum / Masalah Keuangan"
                    options={[
                      { value: 5, label: 'Tidak Pernah Bermasalah' },
                      { value: 3, label: 'Pernah Masalah Ringan' },
                      { value: 0, label: 'Masalah Serius' },
                    ]}
                    value={formData.catatanHukum}
                    onChange={(v) => handleInputChange('catatanHukum', v)}
                  />
                </div>
              </Card>

              {/* Capacity Scoring */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Capacity (Kapasitas Bayar)</h3>
                <div className="space-y-4">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold text-blue-900">1. Debt Service Ratio (DSR)</p>
                        <p className="text-sm text-gray-600 mt-1">Nilai terukur: {metrics.dsr.toFixed(2)}%</p>
                        <p className="text-xs text-gray-500 mt-2">
                          {metrics.dsr <= 30 && '✓ Cicilan < 30% dari Pendapatan (6 poin)'}
                          {metrics.dsr > 30 && metrics.dsr <= 50 && '• Cicilan 30-50% dari Pendapatan (4 poin)'}
                          {metrics.dsr > 50 && '✗ Cicilan > 50% dari Pendapatan (0 poin)'}
                        </p>
                      </div>
                      <span className="text-xl font-bold text-blue-900">{formData.dsr} pts</span>
                    </div>
                  </div>
                  <ScoreOption
                    label="2. Stabilitas Pendapatan / Pekerjaan"
                    options={[
                      { value: 6, label: 'Pegawai Tetap / Usaha > 5 Tahun' },
                      { value: 3, label: 'Pegawai Kontrak / Usaha 2-5 Tahun' },
                      { value: 0, label: 'Bekerja < 1 Tahun / Usaha Baru' },
                    ]}
                    value={formData.stabilitasPendapatan}
                    onChange={(v) => handleInputChange('stabilitasPendapatan', v)}
                  />
                  <ScoreOption
                    label="3. Pertumbuhan Keuntungan"
                    options={[
                      { value: 6, label: 'Meningkat' },
                      { value: 3, label: 'Stabil' },
                      { value: 0, label: 'Menurun' },
                    ]}
                    value={formData.pertumbuhanKeuntungan}
                    onChange={(v) => handleInputChange('pertumbuhanKeuntungan', v)}
                  />
                  {formData.jenisPekerjaan === 'wiraswasta' && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-semibold text-blue-900">4. Rasio BOPO (Biaya Operasional)</p>
                          <p className="text-sm text-gray-600 mt-1">Nilai terukur: {(metrics.der * 100).toFixed(2)}%</p>
                          <p className="text-xs text-gray-500 mt-2">
                            {(metrics.der * 100) <= 50 && '✓ Biaya Operasional Rendah (6 poin)'}
                            {(metrics.der * 100) > 50 && (metrics.der * 100) <= 75 && '• Biaya Operasional Sedang (3 poin)'}
                            {(metrics.der * 100) > 75 && '✗ Biaya Operasional Sangat Tinggi (0 poin)'}
                          </p>
                        </div>
                        <span className="text-xl font-bold text-blue-900">{formData.bopo} pts</span>
                      </div>
                    </div>
                  )}
                </div>
              </Card>

              {/* Capital Scoring */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Capital (Kualitas Sumber Pendapatan)</h3>
                <div className="space-y-4">
                  <ScoreOption
                    label="1. Besaran Modal Sendiri (Self-Financing)"
                    options={[
                      { value: 6, label: 'Modal Sendiri > 50%' },
                      { value: 3, label: 'Modal Sendiri 20-50%' },
                      { value: 0, label: 'Modal Sendiri < 20%' },
                    ]}
                    value={formData.selfFinancing}
                    onChange={(v) => handleInputChange('selfFinancing', v)}
                  />
                  <ScoreOption
                    label="2. Rasio Hutang terhadap Modal (DER)"
                    options={[
                      { value: 6, label: 'Hutang < Modal' },
                      { value: 3, label: 'Hutang Setara Modal' },
                      { value: 0, label: 'Hutang > Modal' },
                    ]}
                    value={formData.der}
                    onChange={(v) => handleInputChange('der', v)}
                  />
                  <ScoreOption
                    label="3. Kepemilikan Aset Likuid"
                    options={[
                      { value: 6, label: 'Aset Likuid Besar' },
                      { value: 3, label: 'Aset Likuid Cukup' },
                      { value: 0, label: 'Tidak Ada Aset Likuid' },
                    ]}
                    value={formData.asetLikuidScore}
                    onChange={(v) => handleInputChange('asetLikuidScore', v)}
                  />
                </div>
              </Card>

              {/* Collateral Scoring */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Collateral (Jaminan)</h3>
                <div className="space-y-4">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold text-blue-900">1. Loan to Value (LTV)</p>
                        <p className="text-sm text-gray-600 mt-1">Nilai terukur: {metrics.ltv.toFixed(2)}% (Plafon / Harga Properti)</p>
                        <p className="text-xs text-gray-500 mt-2">
                          {metrics.ltv < 80 && '✓ LTV < 80% (10 poin) - Sangat Aman'}
                          {metrics.ltv >= 80 && metrics.ltv <= 100 && '• LTV 80-100% (6 poin) - Cukup Aman'}
                          {metrics.ltv > 100 && '✗ LTV > 100% (0 poin) - Tidak Layak'}
                        </p>
                      </div>
                      <span className="text-xl font-bold text-blue-900">{formData.ltv} pts</span>
                    </div>
                  </div>
                  <ScoreOption
                    label="2. Likuiditas Jaminan"
                    options={[
                      { value: 5, label: 'Sangat Likuid' },
                      { value: 3, label: 'Cukup Likuid' },
                      { value: 0, label: 'Sulit Dilikuidasi' },
                    ]}
                    value={formData.likuiditasJaminan}
                    onChange={(v) => handleInputChange('likuiditasJaminan', v)}
                  />
                  <ScoreOption
                    label="3. Legalitas Jaminan"
                    options={[
                      { value: 5, label: 'SHM Atas Nama Sendiri' },
                      { value: 3, label: 'SHGB / Atas Nama Orang Lain' },
                      { value: 0, label: 'Dokumen Tidak Lengkap / Sengketa' },
                    ]}
                    value={formData.legalitasJaminan}
                    onChange={(v) => handleInputChange('legalitasJaminan', v)}
                  />
                </div>
              </Card>

              {/* Condition Scoring */}
              <Card className="p-6 bg-white border border-gray-200">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Condition (Kondisi Kehidupan Nasabah)</h3>
                <div className="space-y-4">
                  <ScoreOption
                    label="1. Jenis Pekerjaan"
                    options={[
                      { value: 5, label: 'Pegawai Negeri / BUMN' },
                      { value: 3, label: 'Pegawai Swasta Tetap' },
                      { value: 0, label: 'Wiraswasta / Lainnya' },
                    ]}
                    value={formData.jenisPekerjaanScore}
                    onChange={(v) => handleInputChange('jenisPekerjaanScore', v)}
                  />
                  <ScoreOption
                    label="2. Prospek Sektor"
                    options={[
                      { value: 5, label: 'Sektor Berkembang Pesat' },
                      { value: 3, label: 'Sektor Stabil' },
                      { value: 0, label: 'Sektor Berisiko / Menurun' },
                    ]}
                    value={formData.prospekSektor}
                    onChange={(v) => handleInputChange('prospekSektor', v)}
                  />
                </div>
              </Card>

              <Button
                onClick={() => setStage('scoring')}
                className="w-full py-3 bg-blue-900 text-white hover:bg-blue-800"
              >
                Proses Penilaian
              </Button>
            </div>

            {/* Right - Metrics Display */}
            <div className="col-span-1 space-y-4">
              <div className="sticky top-6">
                <Card className="p-4 bg-blue-50 border border-blue-200">
                  <h4 className="font-bold text-blue-900 mb-4">Metrik Otomatis</h4>
                  <div className="space-y-3 text-sm">
                    <MetricRow label="Plafon KPR" value={`Rp ${metrics.plafon.toLocaleString('id-ID')}`} />
                    <MetricRow label="Cicilan Bulanan" value={`Rp ${metrics.cicilan.toLocaleString('id-ID')}`} />
                    <MetricRow label="DBR" value={`${metrics.dbr.toFixed(2)}%`} status={getDBRStatus(metrics.dbr)} />
                    <MetricRow label="DSR" value={`${metrics.dsr.toFixed(2)}%`} />
                    <MetricRow label="LTV" value={`${metrics.ltv.toFixed(2)}%`} />
                    <MetricRow label="DER" value={`${metrics.der.toFixed(2)}`} />
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scoring Stage */}
      {stage === 'scoring' && (
        <div className="max-w-2xl mx-auto px-6 py-20 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Memproses Penilaian</h2>
          <p className="text-gray-600 mb-8">Sistem akan menghitung skor komprehensif berdasarkan data dan penilaian yang telah diisi</p>
          <div className="flex gap-4 justify-center">
            <Button onClick={() => setStage('form')} variant="outline">Kembali</Button>
            <Button onClick={handleProcess} className="bg-blue-900 text-white hover:bg-blue-800">
              Proses Sekarang
            </Button>
          </div>
        </div>
      )}

      {/* Results Stage */}
      {stage === 'results' && result && (
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="grid grid-cols-3 gap-8">
            {/* Results */}
            <div className="col-span-2 space-y-6">
              {/* DBR Check */}
              {result.metrics.dbr > 50 ? (
                <Card className="p-6 border-2 border-red-300 bg-red-50">
                  <div className="flex gap-3 mb-4">
                    <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-lg font-bold text-red-900">Pengajuan Ditolak</h3>
                      <p className="text-red-800 text-sm mt-1">
                        DBR ({result.metrics.dbr.toFixed(2)}%) melebihi batas maksimal 50%
                      </p>
                    </div>
                  </div>
                </Card>
              ) : (
                <>
                  {/* Decision */}
                  <Card className={`p-6 border-2 ${
                    result.decision === 'approved' ? 'border-green-300 bg-green-50' :
                    result.decision === 'considered' ? 'border-yellow-300 bg-yellow-50' :
                    result.decision === 'risky' ? 'border-orange-300 bg-orange-50' :
                    'border-red-300 bg-red-50'
                  }`}>
                    <div className="flex gap-3 items-start">
                      {result.decision === 'approved' && <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />}
                      {result.decision === 'considered' && <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />}
                      {result.decision === 'risky' && <AlertCircle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />}
                      {result.decision === 'rejected' && <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />}
                      <div>
                        <h3 className="text-lg font-bold">
                          {result.decision === 'approved' && 'Layak Disetujui'}
                          {result.decision === 'considered' && 'Dipertimbangkan'}
                          {result.decision === 'risky' && 'Risiko Tinggi'}
                          {result.decision === 'rejected' && 'Ditolak'}
                        </h3>
                        <p className="text-sm mt-1">
                          Total Skor: {result.total} / 100
                        </p>
                      </div>
                    </div>
                  </Card>

                  {/* Scores */}
                  <div className="grid grid-cols-2 gap-4">
                    <ScoreCard label="Character" score={result.character} maxScore={30} />
                    <ScoreCard label="Capacity" score={result.capacity} maxScore={25} />
                    <ScoreCard label="Capital" score={result.capital} maxScore={20} />
                    <ScoreCard label="Collateral" score={result.collateral} maxScore={15} />
                    <ScoreCard label="Condition" score={result.condition} maxScore={10} />
                  </div>

                  {/* Metrics */}
                  <Card className="p-6 bg-white border border-gray-200">
                    <h4 className="font-bold text-blue-900 mb-4">Metrik Perhitungan</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <MetricRow label="DBR" value={`${result.metrics.dbr.toFixed(2)}%`} />
                      <MetricRow label="DSR" value={`${result.metrics.dsr.toFixed(2)}%`} />
                      <MetricRow label="LTV" value={`${result.metrics.ltv.toFixed(2)}%`} />
                      <MetricRow label="DER" value={`${result.metrics.der.toFixed(2)}`} />
                    </div>
                  </Card>
                </>
              )}
            </div>

            {/* Summary */}
            <div>
              <Card className="p-6 bg-gray-50 border border-gray-200 sticky top-6">
                <h4 className="font-bold text-blue-900 mb-4">Ringkasan Simulasi</h4>
                <div className="space-y-3 text-sm">
                  <SummaryRow label="Harga Properti" value={`Rp ${formData.hargaProperti.toLocaleString('id-ID')}`} />
                  <SummaryRow label="Uang Muka" value={`Rp ${formData.dp.toLocaleString('id-ID')}`} />
                  <SummaryRow label="Plafon KPR" value={`Rp ${result.metrics.plafon.toLocaleString('id-ID')}`} />
                  <SummaryRow label="Tenor" value={`${formData.tenor} tahun`} />
                  <SummaryRow label="Suku Bunga" value={`${formData.sukuBunga}%`} />
                  <SummaryRow label="Cicilan Bulanan" value={`Rp ${result.metrics.cicilan.toLocaleString('id-ID')}`} />
                  <hr className="my-3" />
                  <SummaryRow label="Pendapatan Bersih" value={`Rp ${formData.pendapatanBersih.toLocaleString('id-ID')}`} />
                  <SummaryRow label="Cicilan Berjalan" value={`Rp ${formData.cicilanBerjalan.toLocaleString('id-ID')}`} />
                  <SummaryRow label="Total Cicilan" value={`Rp ${(result.metrics.cicilan + formData.cicilanBerjalan).toLocaleString('id-ID')}`} />
                </div>
              </Card>
            </div>
          </div>

          <div className="flex gap-4 mt-8 justify-center">
            <Button onClick={handleReset} className="bg-gray-500 text-white hover:bg-gray-600">
              Mulai Ulang
            </Button>
            <Button onClick={() => window.print()} className="bg-blue-900 text-white hover:bg-blue-800">
              Cetak Laporan
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// Helper Components
function ScoreOption({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { value: number; label: string }[];
  value: number | '';
  onChange: (v: number) => void;
}) {
  return (
    <div className="border border-gray-200 rounded p-4 bg-gray-50">
      <p className="text-sm font-semibold text-gray-900 mb-3">{label}</p>
      <div className="space-y-2">
        {options.map((opt) => (
          <label key={opt.value} className="flex items-center gap-3 cursor-pointer">
            <input
              type="radio"
              name={label}
              value={opt.value}
              checked={value === opt.value}
              onChange={(e) => onChange(parseInt(e.target.value))}
              className="w-4 h-4"
            />
            <span className="text-sm text-gray-700">{opt.label}</span>
            <span className="ml-auto text-xs font-semibold text-blue-900 bg-blue-100 px-2 py-1 rounded">
              {opt.value} pts
            </span>
          </label>
        ))}
      </div>
    </div>
  );
}

function ScoreCard({
  label,
  score,
  maxScore,
}: {
  label: string;
  score: number;
  maxScore: number;
}) {
  const percentage = (score / maxScore) * 100;
  return (
    <Card className="p-4 bg-white border border-gray-200">
      <p className="text-sm font-semibold text-gray-700 mb-2">{label}</p>
      <p className="text-2xl font-bold text-blue-900">{score}/{maxScore}</p>
      <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
        <div
          className="bg-blue-900 h-2 rounded-full transition-all"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </Card>
  );
}

function MetricRow({
  label,
  value,
  status,
}: {
  label: string;
  value: string;
  status?: 'good' | 'warning' | 'bad';
}) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-700">{label}</span>
      <span className={`font-semibold ${
        status === 'good' ? 'text-green-700' :
        status === 'warning' ? 'text-yellow-700' :
        status === 'bad' ? 'text-red-700' :
        'text-gray-900'
      }`}>
        {value}
      </span>
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-700">{label}</span>
      <span className="font-semibold text-gray-900">{value}</span>
    </div>
  );
}

function getDBRStatus(dbr: number): 'good' | 'warning' | 'bad' {
  if (dbr <= 30) return 'good';
  if (dbr <= 50) return 'warning';
  return 'bad';
}
