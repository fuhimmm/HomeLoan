'use client';

interface ScoreItem {
  label: string;
  score: number;
  maxScore: number;
  details?: string[];
}

interface ResultsDisplayProps {
  scores: ScoreItem[];
  totalScore: number;
  maxTotalScore: number;
  decision: string;
  decisionColor: string;
  dbr?: number;
  dsr?: number;
  ltv?: number;
  der?: number;
}

export function ResultsDisplay({
  scores,
  totalScore,
  maxTotalScore,
  decision,
  decisionColor,
  dbr,
  dsr,
  ltv,
  der,
}: ResultsDisplayProps) {
  const percentage = Math.round((totalScore / maxTotalScore) * 100);

  return (
    <div className="space-y-6">
      {/* Total Score Card */}
      <div className={`${decisionColor} text-white rounded-lg p-8`}>
        <h3 className="text-lg font-semibold mb-4">Hasil Penilaian</h3>
        <div className="grid grid-cols-2 gap-8 mb-6">
          <div>
            <p className="text-sm opacity-90 mb-2">Total Skor</p>
            <p className="text-4xl font-bold">
              {totalScore}
              <span className="text-xl ml-2">/ {maxTotalScore}</span>
            </p>
          </div>
          <div>
            <p className="text-sm opacity-90 mb-2">Keputusan</p>
            <p className="text-2xl font-bold">{decision}</p>
          </div>
        </div>
        <div className="w-full bg-white bg-opacity-30 rounded-full h-2">
          <div
            className="bg-white rounded-full h-2"
            style={{ width: `${percentage}%` }}
          ></div>
        </div>
        <p className="text-sm mt-2 opacity-90">{percentage}% dari skor maksimal</p>
      </div>

      {/* Score Breakdown */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Rincian Skor</h3>
        <div className="space-y-4">
          {scores.map((item, idx) => (
            <div key={idx} className="border-b border-gray-200 pb-4 last:border-b-0">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-semibold text-gray-900">{item.label}</h4>
                <span className="font-bold text-blue-900">
                  {item.score} / {item.maxScore}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                <div
                  className="bg-blue-900 rounded-full h-2"
                  style={{ width: `${(item.score / item.maxScore) * 100}%` }}
                ></div>
              </div>
              {item.details && (
                <ul className="text-xs text-gray-600 mt-2 space-y-1">
                  {item.details.map((detail, i) => (
                    <li key={i}>• {detail}</li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Financial Metrics */}
      {(dbr !== undefined || dsr !== undefined || ltv !== undefined || der !== undefined) && (
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Metrik Keuangan</h3>
          <div className="grid grid-cols-2 gap-4">
            {dbr !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">DBR (Debt-to-Income Ratio)</p>
                <p className="text-2xl font-bold text-gray-900">{dbr.toFixed(2)}%</p>
                <p className="text-xs text-gray-500 mt-1">Ideal: &lt; 50%</p>
              </div>
            )}
            {dsr !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">DSR (Debt Service Ratio)</p>
                <p className="text-2xl font-bold text-gray-900">{dsr.toFixed(2)}%</p>
                <p className="text-xs text-gray-500 mt-1">Ideal: &lt; 60%</p>
              </div>
            )}
            {ltv !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">LTV (Loan-to-Value)</p>
                <p className="text-2xl font-bold text-gray-900">{ltv.toFixed(2)}%</p>
                <p className="text-xs text-gray-500 mt-1">Ideal: &lt; 80%</p>
              </div>
            )}
            {der !== undefined && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">DER (Debt-to-Equity)</p>
                <p className="text-2xl font-bold text-gray-900">{der.toFixed(2)}</p>
                <p className="text-xs text-gray-500 mt-1">Ideal: &lt; 2.0</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
